<?php
session_start();

unset($_SESSION["logged_in"]);

if(!isset($_SESSION['logged_in'])){
    header('Location:../../pages/samples/login.php');
  }
?>