<?php

include_once('connection.php');

if (isset($_GET['id'])){
  //display articles
  $id = $_GET['id'];
  

// sql to delete a record
$sql = "DELETE FROM noble_articles WHERE id = $id";

   if (mysqli_query($conn, $sql)) {
       
		//$del_message = "Article deleted successfully!!";
        header('Location:../../pages/tables/basic-table.php?delMsg=Article deleted successfully!!');
        echo "Record deleted successfully";
        } else {
          echo "Error deleting record: " . mysqli_error($conn);
        }

}

?>