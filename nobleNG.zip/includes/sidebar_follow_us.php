<!-- Social Follow Start -->
                    <div class="mb-3">
                        <div class="section-title mb-0">
                            <h4 class="m-0 text-uppercase font-weight-bold">Follow Us</h4>
                        </div>
                        <div class="bg-white border border-top-0 p-3">
                            <a href="https://facebook.com/noblenigerianetwork" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #39569E;" target="_blank">
                                <i class="fab fa-facebook-f text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
                                <span class="font-weight-medium">Follow Us</span>
                            </a>
                            <a href="https://twitter.com/noblenigerianetwork" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #52AAF4;" target="_blank">
                                <i class="fab fa-twitter text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
                                <span class="font-weight-medium">Follow Us</span>
                            </a>
                            <!--<a href="" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #0185AE;">
                                <i class="fab fa-linkedin-in text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
                                <span class="font-weight-medium">12,345 Connects</span>
                            </a>-->
                            <a href="https://instagram.com/noblenigerianetwork" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #C8359D;" target="_blank">
                                <i class="fab fa-instagram text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
                                <span class="font-weight-medium">Follow Us</span>
                            </a>
                            <a href="https://www.youtube.com/@noblenigeria" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #DC472E;" target="_blank">
                                <i class="fab fa-youtube text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
                                <span class="font-weight-medium">Subscribe</span>
                            </a>
                            <!--<a href="" class="d-block w-100 text-white text-decoration-none" style="background: #055570;">
                                <i class="fab fa-vimeo-v text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
                                <span class="font-weight-medium">12,345 Followers</span>
                            </a>-->
                        </div>
                    </div>
                    <!-- Social Follow End -->